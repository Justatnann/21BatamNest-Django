// Call the dataTables jQuery plugin
jQuery.noConflict();
(function ($) {
  $(document).ready(function () {
    $("#dataTable").DataTable();
  });
})(jQuery);
